@REM --- To support S2400X01 processor...

set FORCE_TGTCPU=ARM920

REM - USB function support
set BSP_NOUSBSER=

REM Support for SD/MMC
set BSP_NOSD=

@REM - No PCI NE2000 function
set BSP_NIC_NE2000_PCI=

REM - CS8900 Ethernet
set BSP_CS8900=

REM - No PCI bus on this platform -
set BSP_NOPCIBUS=1

@REM --- To support multi-region BINFS on flash
set SYSGEN_MSFLASH=1
set SYSGEN_BINFS=1
