armmake clean
armmake all
