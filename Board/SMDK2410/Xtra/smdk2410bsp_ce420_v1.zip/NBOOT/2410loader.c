//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//
/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
--*/
/************************************************
 * NAME    : 2410loader.C			*
 * DESC    : 					*
 * History : 2002.02.25 ver 0.0			*
************************************************/

#include <stdlib.h>
#include <string.h>
#include "option.h"
#include "def.h"
#include "2410addr.h"
#include "2410lib.h"
#include "2410slib.h"
#include "2410addr.h"
#include "nand.h"
#include "..\inc\loader.h"

#define SIGN_ON "\nWinCE NAND Boot v1.00\n" __DATE__ " " __TIME__ "\n"

// HMSEO : Please check UUID memory location from inc\drv_glob.h file.
unsigned char * pbUUID = ((unsigned char *) (0x30030000 + 0x4608));

//
// Globals
//
DWORD JumpAddr;

DWORD ReadImageFromNand(DWORD dwEntry, DWORD dwSig);

void Main(void)
{
    DWORD 	err; //, t0 = 0;
    
    //	By default, we launch image CE image. If you want to launch
    //	Eboot, you need to hold down APP4 button (sw803) when it boots.
    DWORD	dwEntry = 1;

    MMU_EnableICache();

    Uart_Init();
    Uart_SendString(SIGN_ON);

    NF_Init();

	//	Check to see if the apps buttons are pressed and take
	//	the corresponding actions if they do.
    //  Change this for the final shipping device, so that user
    //  doesn't have to press button to start!
    //
#ifdef P4
    if( (rGPFDAT & 0xF) == 0x07 ) {
        dwEntry = 0;
    }
#else
    //  For P5, the APP buttons are mapped to EINT4-7
    if ((rGPFDAT & 0xF0) == 0x70) {
        dwEntry = 0;
    }
#endif

    Uart_SendString("\ndwEntry is ");
    Uart_SendDWORD(dwEntry, TRUE);

    // Hardcoded to fetch TOC descriptor dwEntry
    err = ReadImageFromNand(dwEntry,0);

    if (ERR_SUCCESS == err) {
        Launch(JumpAddr);
        err = ERR_JUMP_FAILED;
    }

    Uart_SendString("\nBoot ERROR:");
    Uart_SendDWORD(err, TRUE);
    while (1);
}


// -----------------------------------------------------------------------------
//  ReadImageFromNand:
//      Reads nk.nb0 off NAND
//      Returns ERR_Xxx
// -----------------------------------------------------------------------------
TOC toc; // made global because it's too big for our tiny stack

DWORD
ReadImageFromNand(DWORD dwEntry, DWORD dwSig)
{
    DWORD dwSectorsNeeded;
    DWORD dwSector, dwLength;         // Start Sector & Length
    DWORD dwRAM, i;

    if ( !FMD_ReadSector(TOC_SECTOR,
                        (LPBYTE)&toc,
                        NULL, 1) )
    {
        //Uart_SendString("ERR_DISK_OP_FAIL1\n");
        return ERR_DISK_OP_FAIL1;
    }

    if ( !VALID_TOC(&toc) ) {
        Uart_SendString("ERR_INVALID_TOC: ");
        Uart_SendDWORD(toc.dwSignature, TRUE);
        return ERR_INVALID_TOC;
    }

#if 0
    // Disabled for now.
    // Search through the TOC to match the signature
    for(i=0; i<4; i++) {
    	if(toc.id[i].dwSignature && toc.id[i].dwSignature == dwSig) {
    		Uart_SendString("Boot from: ");
   	 		Uart_SendDWORD(i, TRUE);
    		JumpAddr = toc.id[i].dwJumpAddress ? VIRTUAL_TO_PHYSICAL(toc.id[i].dwJumpAddress) :
                                               VIRTUAL_TO_PHYSICAL(toc.id[i].dwLoadAddress);
    		return ERR_SUCCESS;
    	}
    }

    Uart_SendString("Signature mismatch! Load Image from NAND\n");
#endif

    if ( !(toc.id[dwEntry].dwImageType & IMAGE_TYPE_RAMIMAGE) ) {
        Uart_SendString("ERR_INVALID_FILE_TYPE: ");
        Uart_SendDWORD(toc.id[dwEntry].dwImageType, TRUE);
        return ERR_INVALID_FILE_TYPE;
    }

// ??
//    if ( !(toc.id[dwEntry].dwImageType & IMAGE_TYPE_BINFS) ) {
//        dwSectorsNeeded = toc.id[dwEntry].dwTtlSectors;
//    } else {
        dwSectorsNeeded = toc.id[dwEntry].dwTtlSectors;
//    }
	
	Uart_SendString("Sector addr on NAND: ");
	Uart_SendDWORD(toc.id[dwEntry].sgList[0].dwSector, TRUE);
    Uart_SendString("TotalSector: ");
    Uart_SendDWORD(dwSectorsNeeded, TRUE);

    dwRAM    = VIRTUAL_TO_PHYSICAL(toc.id[dwEntry].dwLoadAddress);

    JumpAddr = toc.id[dwEntry].dwJumpAddress ? VIRTUAL_TO_PHYSICAL(toc.id[dwEntry].dwJumpAddress) :
                                               VIRTUAL_TO_PHYSICAL(toc.id[dwEntry].dwLoadAddress);
                                               
    //
    // Load the disk image directly into RAM
    // BUGBUG: recover from read failures
    //
    i = 0;
	while (dwSectorsNeeded && i < MAX_SG_SECTORS)
	{
        dwSector = toc.id[dwEntry].sgList[i].dwSector;
        dwLength = toc.id[dwEntry].sgList[i].dwLength;
        // read each sg segment
        while (dwLength) {

            if ( !FMD_ReadSector(dwSector,
                                (LPBYTE)dwRAM,
                                NULL, 1) )
            {
                Uart_SendString("ERR_DISK_OP_FAIL2: ");
                Uart_SendDWORD(dwSector, TRUE);

	    		dwSector++;
				continue;

//                return ERR_DISK_OP_FAIL2;
            }
            
    		dwSector++;
    		dwLength--;
            dwRAM += SECTOR_SIZE;
        }

        dwSectorsNeeded -= toc.id[dwEntry].sgList[i].dwLength;
        i++;
    }

//    if ( toc.id[dwEntry].dwImageType == 6 )		// For WinCE 4.2 Image
//		toc.chainInfo.dwLoadAddress = toc.id[dwEntry].dwLoadAddress;

    //  We only do this if the dwRAM is not zero (The default tocblock1 
    //  set the dwRAM to be 0)
    if (toc.chainInfo.dwLoadAddress == 0) {
        return ERR_SUCCESS;
    }

    // Load the Chain.bin stored on NAND to the SDRAM
	if ( toc.id[dwEntry].dwImageType == 6 )		// For WinCE 4.2 Image
	{
//		dwRAM = VIRTUAL_TO_PHYSICAL(toc.id[dwEntry].dwLoadAddress);
//		dwSectorsNeeded = toc.id[dwEntry].sgList->dwLength;
//		dwSector = toc.id[dwEntry].sgList->dwSector;
	    return ERR_SUCCESS;
	}
	else
	{
		dwRAM = VIRTUAL_TO_PHYSICAL(toc.chainInfo.dwLoadAddress);
		dwSectorsNeeded = toc.chainInfo.dwLength;
		dwSector = toc.chainInfo.dwFlashAddress;
	}

	// Copy UUID to SDRAM drv_glob area from NAND
    Uart_SendString("Reading UUID from NAND : ");

	for ( i = 0; i < 8; i++ )
	{
		*pbUUID = toc.udid[i];
//		Uart_SendByte(*pbUUID);
//		Uart_SendDWORD(*pbUUID, FALSE);
//	    Uart_SendString(": ");
		pbUUID++;
	}
    Uart_SendString("\r\n");

    Uart_SendString("Reading Chain from NAND\r\n");
    Uart_SendString("LoadAddr: ");
    Uart_SendDWORD(dwRAM, TRUE);
    Uart_SendString("NAND SectorAddr: ");
    Uart_SendDWORD(dwSector, TRUE);
    Uart_SendString("Length: ");
    Uart_SendDWORD(dwSectorsNeeded, TRUE);
    Uart_SendString("\r\n                     ");

    while(dwSectorsNeeded) {
        
        if (!FMD_ReadSector(dwSector, 
                            (LPBYTE) dwRAM,
                            NULL, 1) ) {
            Uart_SendString("Failed reading Chain.bin:");
            Uart_SendDWORD(dwSector, TRUE);

			dwSector++;
			continue;

        }

        dwSector++;
        dwSectorsNeeded--;
        dwRAM += SECTOR_SIZE;
    }
    return ERR_SUCCESS;
}

