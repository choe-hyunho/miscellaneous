@REM
@REM Copyright (c) Microsoft Corporation.  All rights reserved.
@REM
@REM
@REM Use of this source code is subject to the terms of the Microsoft end-user
@REM license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
@REM If you did not accept the terms of the EULA, you are not authorized to use
@REM this source code. For a copy of the EULA, please see the LICENSE.RTF on your
@REM install media.
@REM
@echo off
REM
REM ** This batch file renames nk.bin and updates the multi-region manifest file. **
REM ** This platform uses a multi-region image and we're renaming nk.bin to avoid **
REM ** the case where it's mistakenly downloaded instead of xip.bin or chain.lst. **
REM
cd /d %_FLATRELEASEDIR%
REM copy /y nk.bin core.bin > nul
REM del /f nk.bin > nul
REM echo +CORE.BIN > chain.new
REM type chain.lst | findstr /i /v +nk.bin >> chain.new
REM copy /y chain.new chain.lst > nul
REM del /f  chain.new > nul
