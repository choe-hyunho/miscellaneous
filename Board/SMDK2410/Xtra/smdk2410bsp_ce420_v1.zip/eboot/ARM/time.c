//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//

//#include "..\..\KERNEL\HAL\ARM\TIMER.C"

#if 1
#include <windows.h>

#include "s2410.h"
#include "warning.h"

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
#define FROM_BCD(n)     ((((n) >> 4) * 10) + ((n) & 0xf))

BOOL 
OEMGetRealTime(LPSYSTEMTIME lpst) 
{
    volatile RTCreg *s2410RTC = (RTCreg *)RTC_BASE;
    
    lpst->wSecond    = FROM_BCD(s2410RTC->rBCDSEC );
    lpst->wMinute    = FROM_BCD(s2410RTC->rBCDMIN );
    lpst->wHour      = FROM_BCD(s2410RTC->rBCDHOUR);

    lpst->wDayOfWeek = s2410RTC->rBCDDATE - 1;

    lpst->wDay       = FROM_BCD(s2410RTC->rBCDDAY );
    lpst->wMonth     = FROM_BCD(s2410RTC->rBCDMON );
    lpst->wYear      = FROM_BCD(s2410RTC->rBCDYEAR) + 2000;

    return TRUE;
}

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

#define TO_BCD(n)       ((((DWORD)(n) / 10) << 4) | ((DWORD)(n) % 10))

BOOL 
OEMSetRealTime(LPSYSTEMTIME lpst) 
{
    volatile INTreg *s2410INT = (INTreg *)INT_BASE;
    volatile RTCreg *s2410RTC = (RTCreg *)RTC_BASE;
    
    s2410RTC->rRTCCON = (1 << 3) | (1 << 0);        /* RTC Control Enable & Reset   */
    
    s2410RTC->rBCDSEC  = (unsigned char)TO_BCD(lpst->wSecond );
    s2410RTC->rBCDMIN  = (unsigned char)TO_BCD(lpst->wMinute );
    s2410RTC->rBCDHOUR = (unsigned char)TO_BCD(lpst->wHour   );

    s2410RTC->rBCDDATE = (unsigned char)(lpst->wDayOfWeek + 1);
    s2410RTC->rBCDDAY  = (unsigned char)TO_BCD(lpst->wDay    );
    s2410RTC->rBCDMON  = (unsigned char)TO_BCD(lpst->wMonth  );
    s2410RTC->rBCDYEAR = (unsigned char)TO_BCD(((DWORD)lpst->wYear % 100));

    s2410RTC->rRTCCON = (0 << 0);                   /* RTC Control Disable          */

    s2410INT->rSRCPND  =  BIT_RTC;                  /* RTC Alarm Interrupt Clear    */
    s2410INT->rINTPND  =  BIT_RTC;
    s2410INT->rINTMSK &= ~BIT_RTC;                  /* RTC Alarm Enable             */

    return TRUE;
}
#endif
