@REM
@REM Copyright (c)Samsung Elec. co, LTD.  All rights reserved.
@REM
@echo off
REM ** NDIS DLL  build script **

SET B_TMP=%WINCEDEBUG%

IF "%1" == "D" set WINCEDEBUG=debug
IF "%1" == "d" set WINCEDEBUG=debug
IF "%1" == "R" set WINCEDEBUG=retail
IF "%1" == "r" set WINCEDEBUG=retail

@rem pushd %_PRIVATEROOT%\common\oak\drivers\netcard\cs8900r
pushd %_PRIVATEROOT%\WINCEOS\COMM\ndis51
build %2
popd

pushd %_PUBLICROOT%\common\cesysgen
nmake ndis
popd

copy /Y %_PROJECTROOT%\cesysgen\oak\target\%_TGTCPU%\%WINCEDEBUG%\ndis.* %_FLATRELEASEDIR%

set WINCEDEBUG=%B_TMP%