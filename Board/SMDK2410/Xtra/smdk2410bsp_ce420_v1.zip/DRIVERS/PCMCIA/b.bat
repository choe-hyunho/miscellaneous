@REM
@REM Copyright (c)Samsung Elec. co, LTD.  All rights reserved.
@REM
@echo off
REM ** S3C2410 pcmcia driver build script **

SET B_TMP=%WINCEDEBUG%

IF "%1" == "D" set WINCEDEBUG=debug
IF "%1" == "d" set WINCEDEBUG=debug
IF "%1" == "R" set WINCEDEBUG=retail
IF "%1" == "r" set WINCEDEBUG=retail

pushd %_PUBLICROOT%\common\oak\drivers\pcmcia
build %2
popd

pushd %_PUBLICROOT%\common\cesysgen
nmake cardserv
popd

REM build %2
build -cfs

copy /Y %_TARGETPLATROOT%\target\%_TGTCPU%\%WINCEDEBUG%\pcmcia.* %_FLATRELEASEDIR%

set WINCEDEBUG=%B_TMP%

