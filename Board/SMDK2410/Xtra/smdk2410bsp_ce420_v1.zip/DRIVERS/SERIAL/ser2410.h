/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
Copyright (c) 1995-2000 Microsoft Corporation.  All rights reserved.

Module Name:  
   SER_PDD.h
   
Abstract:  
   Holds definitions for sample 16550  serial interface.
   
Notes: 
--*/
#ifndef __SER_PDD_H__   
    #define __SER_PDD_H__

    #ifdef __cplusplus
extern "C" {
    #endif

// TODO - Define PAGE_CONTAINING_UART
    #define PAGE_CONTAINING_UART   XXXXX

/*
 * @doc HWINTERNAL
 * @struct SER_INFO | Private structure.
 */


/* 
 * S2400 UART1 register values
 */

// Line Status Register    
#define  COM2410_LSR_OE     0x1
#define  COM2410_LSR_PE     0x2
#define  COM2410_LSR_FE     0x4
#define  COM2410_LSR_BI     0x8   //Break Detect
// dummy value 
#define  COM2410_LSR_THRE   0xe
#define  COM2410_LSR_DR     0xf
// Fifo Status Register

// following two cts values are read from modem control register.
#define  COM2410_MSR_CTS    0x1
#define  COM2410_MSR_DCTS   0x4
// following two cts values are read from modem GIO port.
#define  COM2410_MSR_DSR    0x2
#define  COM2410_MSR_DDSR    0x8

typedef struct {
      PS2410_UART_REG s2410SerReg;

      volatile unsigned char *pUFTXH;  // Tx holding register for byte access.
      volatile unsigned char *pUFRXH;  // Rx holding register for byte access.
      volatile unsigned int *UART_INTMASK;
      volatile unsigned int *UART_INTSUBMASK;
      volatile unsigned int *UART_INTPND;
      volatile unsigned int *UART_INTSRCPND;
      volatile unsigned int *UART_INTSUBSRCPND;
      //volatile unsigned int *UART_INTOFFSET;
      //ULONG nTxINT;
      //ULONG nRxINT;
      ULONG bINT;
      ULONG bTxINT;
      ULONG bRxINT;
      ULONG bErrINT;
      BOOL fSW_EnTxINT;   // S/W flag of Enable Tx interrupt.
      BOOL RxDiscard;   // S/W flag of Enable Tx interrupt.
      BOOL UseIrDA;        // @field Boolean, are we running in IR mode?
      int ConSetup;
      // ULONG nRxErrINT;  // reserved for future...
      volatile unsigned int *rDTRport;
      int DtrPortNum;
      volatile unsigned int *rDSRport;
      int DsrPortNum;

      // These variable are for saving register values.
      ULONG sULCON;
      ULONG sUCON;
      ULONG sUMCON;
      ULONG sUFCON;
      ULONG sINTstat;

      ULONG vUMSTAT;
      
       // We have an event callback into the MDD
      EVENT_FUNC EventCallback; // This callback exists in MDD
      PVOID        pMddHead;  // This is the first parm to callback

       // Keep a copy of DCB since we rely on may of its parms
      DCB         dcb;        // @field Device Control Block (copy of DCB in MDD)
       // And the same thing applies for CommTimeouts
      COMMTIMEOUTS CommTimeouts;  // @field Copy of CommTimeouts structure

       // Misc fields used by ser16550 library
      ULONG OpenCount;	    // @field Count of simultaneous opens. 
      PLOOKUP_TBL pBaudTable;     // @field Pointer to Baud Table
      ULONG		DroppedBytes;	// @field Number of dropped bytes 
      HANDLE		FlushDone;		// @field Handle to flush done event.
      BOOL		CTSFlowOff;		// @field Flag - CTS flow control state. 
      BOOL		DSRFlowOff;		// @field Flag - DSR flow control state. 
      BOOL		AddTXIntr;		// @field Flag - Fake a TX intr.
      COMSTAT		Status; 		// @field Bitfield representing Win32 comm status. 
      ULONG		CommErrors;		// @field Bitfield representing Win32 comm error status. 
      ULONG		ModemStatus;	// @field Bitfield representing Win32 modem status. 
      CRITICAL_SECTION	TransmitCritSec; // @field Protects UART Registers for non-atomic accesses
      CRITICAL_SECTION	RegCritSec; // @field Protects UART 
      ULONG		ChipID;			// @field Chip identifier (CHIP_ID_16550 or CHIP_ID_16450)        

    } S2410_UART_INFO, * PS2410_UART_INFO;

    typedef struct __SER_INFO {
        // Put lib struct first so we can easily cast pointers
        //SER16550_INFO ser16550;
        S2410_UART_INFO s2410COM;   // UART H/W register
        // now hardware specific fields
        DWORD       dwIOBase;       // @field IO Base Address - unmapped
        DWORD       dwIOLen;        // @field IO Length
        DWORD       dwIRQ;          // @field Interrupt number for this peripheral
        DWORD       dwDevIndex;     // @field Index of device

        PUCHAR      pBaseAddress;   // @field Start of serial registers - mapped

        UINT8       cOpenCount;     // @field Count of concurrent opens
        COMMPROP    CommProp;       // @field Pointer to CommProp structure.
        PVOID       pMddHead;       // @field First arg to mdd callbacks.
        BOOL        fIRMode;        // @field Boolean, are we running in IR mode?
    #ifdef EXAMINE_BOOTARGS
        PBOOT_ARGS  pBootArgs;      // @field Pointer to global boot args struct
    #endif    
        PHWOBJ      pHWObj;         // @field Pointer to PDDs HWObj structure
    } SER_INFO, *PSER_INFO;


// Here are the names of the values stored in the registry
    #define PC_REG_IRQ_VAL_NAME TEXT("IRQ") 
    #define PC_REG_IRQ_VAL_LEN  sizeof( DWORD )

    #define PC_REG_IOBASE_VAL_NAME TEXT("IoBase") 
    #define PC_REG_IOBASE_VAL_LEN  sizeof( DWORD )
    #define PC_REG_IOLEN_VAL_NAME TEXT("IoLen") 
    #define PC_REG_IOLEN_VAL_LEN  sizeof( DWORD )

    #define PC_REG_CONFIGBASE_VAL_NAME TEXT("ConfigBase") 
    #define PC_REG_CONFIGBASE_VAL_LEN  sizeof( DWORD )
    #define PC_REG_CONFIGLEN_VAL_NAME TEXT("ConfigLen") 
    #define PC_REG_CONFIGLEN_VAL_LEN  sizeof( DWORD )

    #define PC_REG_DMA_VAL_NAME TEXT("DMA") 
    #define PC_REG_DMA_VAL_LEN  sizeof( DWORD )

    #define PC_REG_DEVINDEX_VAL_NAME TEXT("DeviceArrayIndex") 
    #define PC_REG_DEVINDEX_VAL_LEN  sizeof( DWORD )

    #ifdef __cplusplus
}
    #endif


/////////////////////////////////////////////////////////////////////////////////////////
//// S3C2400 UART Register

///////++ UART CONTROL REGISTER ++
// Line control register bitvalue mask
#define SER2410_PARITY_MASK     0x38
#define SER2410_STOPBIT_MASK    0x4
#define SER2410_DATABIT_MASK    0x3
#define SER2410_IRMODE_MASK     0x40

// Fifo Status
#define SER2410_FIFOSTAT_MASK   0xf0

//
#define SER2410_FIFOFULL_TX     0x200
#define SER2410_FIFOCNT_MASK_TX 0xf0
#define SER2410_FIFO_DEPTH_TX 16

//
#define SER2410_INT_INVALID     0x5a5affff

// Modem control register
#define SER2410_AFC             (0x10)
#define SER2410_RTS             0x1
//Receive Mode
#define RX_MODE_MASK          (0x11)
#define RX_DISABLE            (0x00)
#define RX_INTPOLL            (0x01)
#define RX_DMA0               (0x10)
#define RX_DMA1               (0x11)
//Transmit Mode
#define TX_MODE_MASK          (0x11 << 2)
#define TX_DISABLE            (0x00 << 2)
#define TX_INTPOLL            (0x01 << 2)
#define TX_DMA0               (0x10 << 2)
#define TX_DMA1               (0x11 << 2)
//Send Break Signal
#define BS_MASK               (0x01 << 4)
#define BS_NORM               (0x00 << 4)
#define BS_SEND               (0x01 << 4)
//Loop-back Mode
#define LB_MASK               (0x01 << 5)
#define LB_NORM               (0x00 << 5)
#define LB_MODE               (0x01 << 5)
//Rx Error Status Interrupt Enable
#define RX_EINT_MASK          (0x01 << 6)
#define RX_EINTGEN_OFF        (0x00 << 6)
#define RX_EINTGEN_ON         (0x01 << 6)
//Rx Time Out Enable
#define RX_TIMEOUT_MASK       (0x01 << 7)
#define RX_TIMEOUT_DIS        (0x00 << 7)
#define RX_TIMEOUT_EN         (0x01 << 7)
//Rx Interrupt Type
#define RX_INTTYPE_MASK       (0x01 << 8)
#define RX_INTTYPE_PUSE       (0x00 << 8)
#define RX_INTTYPE_LEVEL      (0x01 << 8)
//Tx Interrupt Type
#define TX_INTTYPE_MASK       (0x01 << 9)
#define TX_INTTYPE_PUSE       (0x00 << 9)
#define TX_INTTYPE_LEVEL      (0x01 << 9)
// Clock selection
#define CS_MASK	(0x01 << 10)
#define CS_PCLK (0x00 << 10)
#define CS_UCLK	(0x01 << 10)

/////////////////////////////////////////////////////////////////////////////////////////


#define INREG(pInfo, reg) (pInfo->s2410SerReg->reg)
#define OUTREG(pInfo, reg, value) (pInfo->s2410SerReg->reg = value)
// set register by orring..
#define SETREG(pInfo, reg, value) (pInfo->s2410SerReg->reg |= value)
#define CLEARREG(pInfo, reg, value) (pInfo->s2410SerReg->reg &= ~value)

#define DisEnINT(pInfo, value) (		*(pInfo->UART_INTMASK) |= (value))
#define DisEnSubINT(pInfo, value) (	*(pInfo->UART_INTSUBMASK) |= (value))

#define EnINT(pInfo, value) (			*(pInfo->UART_INTMASK) &= ~(value))
#define EnSubINT(pInfo, value) ( 		*(pInfo->UART_INTSUBMASK) &= ~(value))

#define GetSubINTStatus(pInfo) ((*(pInfo->UART_INTSUBMASK)) & 0x1ff)

#define ClearINTPnd(pInfo, value) (	*(pInfo->UART_INTSRCPND) = (value))
#define ClearSubINTPnd(pInfo, value) (	*(pInfo->UART_INTSUBSRCPND) = (value))
//#define GetSubINTPndStatus(pInfo) (*(pInfo->UART_INTSUBSRCPND) & 0x1ff)
#define GetSubINTPndStatus(pInfo) 1


#endif __SER_PDD_H__
