//---------------------------------------------------------------------
//  Copyright (c) Microsoft Corporation
//
//  Module Name: NandFlash.dll
//
//---------------------------------------------------------------------

Purpose:
---------

Provide a Flash Media Driver for Microsoft Flash block driver to work with
resident NAND flash on Catfish PCB. 

Design:
--------

FMD is the lowest layer that deals with NAND flash chip directly. Microsoft
Flash block driver access FMD via FMD_xxx interface which is documented in
fmd.h file (catfish\driver\nandflsh\inc). 

Environment varialbe:
---------------------

You need to set BSP_HASNAND to 1 in order to build this component. 

Registry Settings:
------------------

[HKEY_LOCAL_MACHINE\Drivers\BuiltIn\NandFlash]
    "FSD"="fatfs.dll"
    "Prefix"="FAL"
    "Dll"="FLASHDRV.DLL"
    "Order"=dword:1
    "Index"=dword:0
    "Ioctl"=dword:4
    "Folder"="NandFlash"
    "FriendlyName"="NAND FLASH Device Driver"
    
Dependencies:
-------------

The final DLL depends on some libraries in Catfish\Drivers\Nandflsh\buildexe\lib
directory. To make the driver work, you also need to include FATFS in the final
image. 

Testing Applications:
---------------------

There are a set of test application under Catfish\Test\NandTest directory, including
a program: formatflash.exe which allows you to format the whole flash. Microsoft
flash block driver is clever enough that it won't format the portion of flash where
the bootloader and boot image are stored.

Issues and Recommendations:
---------------------------

1) The current implementation is for Windows CE 3.0 environment only. Starting from 
CE 4.0, the storage architecture has changed. You need to modify the drivers as well
as registry setting to compliane to CE 4.x requirements. Luckily, Microsoft Flash
Block Driver will be shipped in CE 4.2, which will provide an official way to 
construct the driver. 

2) Bad block management. The current implementation write bad block mark to the spare
area to mark a block is bad. This may not be the best way to track bad block. It might
make sense to maintain a bad block list somewhere else. For examples, you can dedicate 
a block just for the place holder for bad block. 

3) Performance improvement. The current rev of S3C2410 we have on Catfish doesn't 
support DMA or other means to speed up the read/write throughput. Even though we provide
an assembly function ReadPage512 and WritePage512, it may still not be the most efficient
way. If the device you are using has the later rev of Samsung S3C2410 CPU or its derivatives,
we recommend you to take a look at improving the read/write throughput.


    

