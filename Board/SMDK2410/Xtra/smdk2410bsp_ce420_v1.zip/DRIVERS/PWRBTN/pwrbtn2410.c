/******************************************************************************
 *
 * System On Chip(SOC)
 *
 * Copyright (c) 2002 Software Center, Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Samsung
 * Electronics, Inc("Confidential Information"). You Shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into Samsung.
 *
 *-----------------------------------------------------------------------------
 *
 *  S3C2410 BSP (Windows CE.NET)
 *
 * pbut2410.c : Power Button Driver
 *
 * @author      zartoven@samsung.com (SOC, SWC, SAMSUNG Electronics)
 *
 * @date        2002/04/25
 *
 * Log:
 *	2002/04/25  Start
 *
 ******************************************************************************
 */

/* 
 * This driver uses EINT0 button as POWER ON/OFF Button.
 * 
 */

#include <windows.h>
#include <types.h>
#include <excpt.h>
#include <tchar.h>
#include <cardserv.h>
#include <cardapi.h>
#include <tuple.h>
#include <devload.h>
#include <diskio.h>
#include <nkintr.h>
#include <oalintr.h>
#include <windev.h>

#include "s2410.h"
#include "pwrbtn2410.h"

#define PRIVATE			static
#define PUBLIC

typedef DWORD (*PFN_SetSystemPowerState)(LPCWSTR, DWORD, DWORD);
PFN_SetSystemPowerState gpfnSetSystemPowerState;

PRIVATE HANDLE gPwrButtonIntrEvent;
PRIVATE HANDLE gPwrButtonIntrThread;
PRIVATE BOOL   gOffFlag;

PRIVATE volatile IOPreg * v_pIOPregs;

extern void DriverSleep(DWORD, BOOL);

PRIVATE VOID
PBT_EnableInterrupt(VOID)
{
	v_pIOPregs->rGPFCON  &= ~(0x3 << 0);		/* Set EINT0(GPF0) as EINT0							*/
	v_pIOPregs->rGPFCON  |=  (0x2 << 0);

    v_pIOPregs->rEXTINT0 &= ~(0x7 << 0);		/* Configure EINT0 as Falling Edge Mode				*/
    v_pIOPregs->rEXTINT0 |=  (0x2 << 0);
}

PRIVATE BOOL
PBT_IsPushed(VOID)
{
	return ((v_pIOPregs->rGPFDAT & (1 << 0)) ? FALSE : TRUE);
}

PRIVATE BOOL
PBT_InitializeAddresses(VOID)
{
	BOOL	RetValue = TRUE;

//	RETAILMSG(1, (TEXT(">>> PBT_initalization address..set..\r\n")));

		
	/* IO Register Allocation */

	v_pIOPregs = (volatile IOPreg *)VirtualAlloc(0, sizeof(IOPreg), MEM_RESERVE, PAGE_NOACCESS);
	if (v_pIOPregs == NULL) 
	{
		ERRORMSG(1,(TEXT("For IOPregs : VirtualAlloc failed!\r\n")));
		RetValue = FALSE;
	}
	else 
	{
		if (!VirtualCopy((PVOID)v_pIOPregs, (PVOID)(IOP_BASE), sizeof(IOPreg), PAGE_READWRITE | PAGE_NOCACHE)) 
		{
			ERRORMSG(1,(TEXT("For IOPregs: VirtualCopy failed!\r\n")));
			RetValue = FALSE;
		}
	}
	
	if (!RetValue) 
	{
//		RETAILMSG (1, (TEXT("::: PBT_InitializeAddresses - Fail!!\r\n") ));

		if (v_pIOPregs) 
		{
			VirtualFree((PVOID) v_pIOPregs, 0, MEM_RELEASE);
		}

		v_pIOPregs = NULL;
	}
	else RETAILMSG (1, (TEXT("::: PBT_InitializeAddresses - Success\r\n") ));

	return(RetValue);
}

DWORD
PBT_IntrThread(PVOID pArg)
{

	PBT_InitializeAddresses();

	PBT_EnableInterrupt();

	gPwrButtonIntrEvent = CreateEvent(NULL, FALSE, FALSE, NULL);

	if (!(InterruptInitialize(SYSINTR_POWER, gPwrButtonIntrEvent, 0, 0))) 
	{
		RETAILMSG(1, (TEXT("::: SYSINTR_POWER Init Fail\r\n")));
	}

	while (1) 
	{
		WaitForSingleObject(gPwrButtonIntrEvent, INFINITE);
	
    	if (gOffFlag == FALSE) 
		{
			if (PBT_IsPushed())			/* To Filter Noise				*/
			{
				Sleep(200);

				if (PBT_IsPushed())
				{  
//					RETAILMSG(1, (TEXT("::: Back Light On/Off \r\n")));
				} 
				else 
				{
                                    // Soft reset and standard suspend-resume both start with suspend for now.
                                    #if (WINCEOSVER >= 400)
                                        // call whichever shutdown API is available
                                        if(gpfnSetSystemPowerState != NULL)
                                        {
                                            gpfnSetSystemPowerState(NULL, POWER_STATE_SUSPEND, POWER_FORCE);
                                        }
                                        else
                                        {
                                            PowerOffSystem();
                                        }
                                    #else
                                        PowerOffSystem();
                                    #endif
        
                                    // Give control back to system if it wants it for anything.  Not in
                                    //  power handling mode yet.  All suspend and resume operations
                                    //  will be performed in the PowerOffSystem() function.
                                    DriverSleep(0, FALSE);
				}
			}

			InterruptDone(SYSINTR_POWER);
    	}
    }        	
}


PUBLIC DWORD
DSK_Init(DWORD dwContext)
{
	PDISK	pDisk;
	DWORD   IDThread;
        HMODULE hmCore;


	pDisk = (PDISK)dwContext;


        // contain the appropriate APIs.
        gpfnSetSystemPowerState = NULL;
        hmCore = (HMODULE) LoadLibrary(_T("coredll.dll"));
        if(hmCore != NULL) {
            gpfnSetSystemPowerState = (PFN_SetSystemPowerState) GetProcAddress(hmCore, _T("SetSystemPowerState"));
            if(gpfnSetSystemPowerState == NULL) {
                FreeLibrary(hmCore);
            }
	}

	do 
	{
		gPwrButtonIntrThread = CreateThread(0, 0, (LPTHREAD_START_ROUTINE) PBT_IntrThread, 0, 0, &IDThread);

//		RETAILMSG(1, (TEXT("::: PBT_IntrThread ID = %x\r\n"), IDThread));

		if (gPwrButtonIntrThread == 0) 
		{
//			RETAILMSG(1, (TEXT("::: CreateThread() Fail\r\n")));
			break;
		}
	} while (0);

//    RETAILMSG(1, (TEXT("::: PBT_Init Out\r\n")));

	pDisk->d_DiskCardState = 1;

	return (DWORD)pDisk;
}

PUBLIC BOOL WINAPI
DllEntry(HANDLE hInstDll, DWORD dwReason, LPVOID lpvReserved)
{
    switch ( dwReason ) 
	{
    case DLL_PROCESS_ATTACH:
//        RETAILMSG(1, (TEXT("PwrButton : DLL_PROCESS_ATTACH\r\n")));
		DisableThreadLibraryCalls((HMODULE) hInstDll);
        break;

    }
    return (TRUE);
}

BOOL
DSK_Close(
    DWORD Handle
    )
{
    return TRUE;
}   // DSK_Close


//
// Device deinit - devices are expected to close down.
// The device manager does not check the return code.
//
BOOL
DSK_Deinit(
    DWORD dwContext     // future: pointer to the per disk structure
    )
{
    return TRUE;
}   // DSK_Deinit


//
// Returns handle value for the open instance.
//
DWORD
DSK_Open(
    DWORD dwData,
    DWORD dwAccess,
    DWORD dwShareMode
    )
{
    return 0;
}   // DSK_Open

//
// I/O Control function - responds to info, read and write control codes.
// The read and write take a scatter/gather list in pInBuf
//
BOOL
DSK_IOControl(
    DWORD Handle,
    DWORD dwIoControlCode,
    PBYTE pInBuf,
    DWORD nInBufSize,
    PBYTE pOutBuf,
    DWORD nOutBufSize,
    PDWORD pBytesReturned
    )
{
    return FALSE;
}   // DSK_IOControl


DWORD DSK_Read(DWORD Handle, LPVOID pBuffer, DWORD dwNumBytes)
{
	return 0;
}
DWORD DSK_Write(DWORD Handle, LPCVOID pBuffer, DWORD dwNumBytes)
{
	return 0;
}
DWORD DSK_Seek(DWORD Handle, long lDistance, DWORD dwMoveMethod)
{
	return 0;
}

void DSK_PowerUp(void)
{
	return;
}

void
DSK_PowerDown(void)
{
	return;
}
