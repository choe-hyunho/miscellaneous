@REM
@REM Copyright (c)Samsung Elec. co, LTD.  All rights reserved.
@REM
@echo off
REM ** S3C2410 touch driver build script **

SET B_TMP=%WINCEDEBUG%

IF "%1" == "D" set WINCEDEBUG=debug
IF "%1" == "d" set WINCEDEBUG=debug
IF "%1" == "R" set WINCEDEBUG=retail
IF "%1" == "r" set WINCEDEBUG=retail

REM pushd %_PUBLICROOT%\common\oak\drivers\touch
REM build %2
REM popd
REM pushd %_PUBLICROOT%\common\oak\drivers\tch_cal
REM build %2
REM popd


REM pushd %_PUBLICROOT%\common\cesysgen
REM nmake tchmdd
REM nmake tch_cal
REM popd

build %2

copy /Y %_TARGETPLATROOT%\target\%_TGTCPU%\%WINCEDEBUG%\touch.* %_FLATRELEASEDIR%

set WINCEDEBUG=%B_TMP%

