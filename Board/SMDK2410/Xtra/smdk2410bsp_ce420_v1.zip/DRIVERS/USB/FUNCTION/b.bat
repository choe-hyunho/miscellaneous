@REM
@REM Copyright (c)Samsung Elec. co, LTD.  All rights reserved.
@REM
@echo off
REM ** S3C2400 USB driver build script **

SET B_TMP=%WINCEDEBUG%

IF "%1" == "D" set WINCEDEBUG=debug
IF "%1" == "d" set WINCEDEBUG=debug
IF "%1" == "R" set WINCEDEBUG=retail
IF "%1" == "r" set WINCEDEBUG=retail

pushd %_PUBLICROOT%\common\oak\drivers\serial\com_mdd2
build %2
popd

pushd %_PUBLICROOT%\common\cesysgen
nmake com_mdd2
popd

build %2

REM copy /Y %_TARGETPLATROOT%\target\%_TGTCPUTYPE%\%_TGTCPU%\%_TGTOS%\%WINCEDEBUG%\sc2400_usb_ser.* %_FLATRELEASEDIR%
copy /Y %_TARGETPLATROOT%\target\%_TGTCPU%\%WINCEDEBUG%\sc2410_usb_ser.* %_FLATRELEASEDIR%

set WINCEDEBUG=%B_TMP%
