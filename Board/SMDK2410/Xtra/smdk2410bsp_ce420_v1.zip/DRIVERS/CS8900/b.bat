@REM
@REM Copyright (c)Samsung Elec. co, LTD.  All rights reserved.
@REM
@echo off
REM ** CS8900 NDIS miniport driver build script **

SET B_TMP=%WINCEDEBUG%

IF "%1" == "D" set WINCEDEBUG=debug
IF "%1" == "d" set WINCEDEBUG=debug
IF "%1" == "R" set WINCEDEBUG=retail
IF "%1" == "r" set WINCEDEBUG=retail

pushd %_PUBLICROOT%\common\oak\drivers\netcard\cs8900r
build %2
popd

pushd %_PUBLICROOT%\common\cesysgen
nmake cs8900
popd

copy /Y %_PROJECTROOT%\cesysgen\oak\target\%_TGTCPU%\%WINCEDEBUG%\cs8900.* %_FLATRELEASEDIR%

set WINCEDEBUG=%B_TMP%