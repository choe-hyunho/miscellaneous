;
; Copyright (c) 2001. Samsung Electronics, co. ltd  All rights reserved.
;
;
; Use of this source code is subject to the terms of the Microsoft end-user
; license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
; If you did not accept the terms of the EULA, you are not authorized to use
; this source code. For a copy of the EULA, please see the LICENSE.RTF on your
; install media.
;
; -*-Asm-*-
;
; $Revision: 1.2 $
;   $Author: kwelton $
;     $Date: 1999/10/25 21:40:55 $
;
; oemabort.s - header file for the data abort veneer
;
; This file selects options suitable for Windows CE's use of
; the data abort veneer.
;

	IF FORCE_TGTCPU = "ARM720"
		GBLS	AreaName
AreaName	SETS	"|.text|"

                GBLS    VeneerEntry
VeneerEntry     SETS    "OEMDataAbortHandler"

                GBLL    BaseUpdated
BaseUpdated     SETL    {TRUE}

                GBLL    BaseRestored
BaseRestored    SETL    {FALSE}

                GBLS    HandlerCallStd
HandlerCallStd  SETS    "APCS_MACRO"

                GBLS    HandlerName
HandlerName     SETS    "HandlerMacro"

                GBLS    ReturnUndef
ReturnUndef     SETS    "0xFFFF0004"

                GBLS    ReturnToNext
ReturnToNext    SETS    "DataAbortHandler"

	ENDIF

	IF FORCE_TGTCPU = "ARM920"
                GBLS    AreaName
AreaName        SETS    "|.text|"

                GBLS    VeneerEntry
VeneerEntry     SETS    "OEMDataAbortHandler"

                GBLL    BaseUpdated
BaseUpdated     SETL    {FALSE}		; NB different to ARM720T

                GBLL    BaseRestored
BaseRestored    SETL    {TRUE}		; NB different to ARM720T 

                GBLS    HandlerCallStd
HandlerCallStd  SETS    "APCS_MACRO"

                GBLS    HandlerName
HandlerName     SETS    "HandlerMacro"

                GBLS    ReturnUndef
ReturnUndef     SETS    "0xFFFF0004"

                GBLS    ReturnToNext
ReturnToNext    SETS    "DataAbortHandler"

	ENDIF

                MACRO
                HandlerMacro
                CMP     R0,#DABORT_ERROR_NONE
                MOVEQ   R0,#DABORT_RETVAL_TONEXT
                MOVNE   R0,#DABORT_RETVAL_UNDEF
                MEND

		INCLUDE dabort.s

                END

; EOF oemabort.s
