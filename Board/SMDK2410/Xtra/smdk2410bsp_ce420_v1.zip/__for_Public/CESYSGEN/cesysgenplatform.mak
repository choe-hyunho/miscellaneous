# Common defines which are normally in sources
NOINCLUDEOBJMAC=1
WINCEOEM=1
!IFNDEF TARGETNAME
TARGETNAME=dummy
!ENDIF
!IFNDEF TARGETTYPE
TARGETTYPE=dummy
!ENDIF
!IFNDEF SOURCES
SOURCES=dummy
!ENDIF

!IF "$(DEL_TAKES_YOPT)"==""
DELFLAGS=/q
MKDIRSFLAGS=
!ELSE
DELFLAGS=/q /y
MKDIRSFLAGS=/s
!ENDIF

!IF "$(PROCESSOR_ARCHITECTURE)"==""
SG_XCOPYREDIRECT=
DELRECURSEFLAG=
!ELSE
SG_XCOPYREDIRECT=2>&1
DELRECURSEFLAG=/S
!ENDIF

SG_TOKENFILTER=cefilter
MAKECMD=$(MAKE) $(NMAKEDEBUG)




cefilter_files:
	@echo Cefilter platform files
!IF !EXIST($(_TARGETPLATROOT)\cesysgen\files)
	mkdir $(_TARGETPLATROOT)\cesysgen\files
!ENDIF
!IF EXIST($(_TARGETPLATROOT)\files\config.bib)
	cefilter $(_TARGETPLATROOT)\files\config.bib $(_TARGETPLATROOT)\cesysgen\files
!ENDIF
!IF EXIST($(_TARGETPLATROOT)\files\platform.bib)
	cefilter $(_TARGETPLATROOT)\files\platform.bib $(_TARGETPLATROOT)\cesysgen\files
!ENDIF
!IF EXIST($(_TARGETPLATROOT)\files\platform.dat)
	cefilter $(_TARGETPLATROOT)\files\platform.dat $(_TARGETPLATROOT)\cesysgen\files
!ENDIF
!IF EXIST($(_TARGETPLATROOT)\files\platform.db)
	cefilter $(_TARGETPLATROOT)\files\platform.db  $(_TARGETPLATROOT)\cesysgen\files
!ENDIF
!IF EXIST($(_TARGETPLATROOT)\files\platform.loc)
	cefilter $(_TARGETPLATROOT)\files\platform.loc $(_TARGETPLATROOT)\cesysgen\files
!ENDIF
!IF EXIST($(_TARGETPLATROOT)\files\platform.reg)
	cefilter $(_TARGETPLATROOT)\files\platform.reg $(_TARGETPLATROOT)\cesysgen\files
!ENDIF

