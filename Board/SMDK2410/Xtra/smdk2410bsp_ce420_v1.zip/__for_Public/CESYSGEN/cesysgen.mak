!IFNDEF WINCEPROJ
!ERROR Your cesysgen\makefile must define the WINCEPROJ macro
!ENDIF

BUILDROOT=$(_PUBLICROOT)\$(WINCEPROJ)\cesysgen

# Common defines which are normally in sources
NOINCLUDEOBJMAC=1
WINCEOEM=1
!IFNDEF TARGETNAME
TARGETNAME=dummy
!ENDIF
!IFNDEF TARGETTYPE
TARGETTYPE=dummy
!ENDIF
!IFNDEF SOURCES
SOURCES=dummy
!ENDIF

!IF "$(DEL_TAKES_YOPT)"==""
DELFLAGS=/q
MKDIRSFLAGS=
!ELSE
DELFLAGS=/q /y
MKDIRSFLAGS=/s
!ENDIF

!IF "$(PROCESSOR_ARCHITECTURE)"==""
SG_XCOPYREDIRECT=
DELRECURSEFLAG=
!ELSE
SG_XCOPYREDIRECT=2>&1
DELRECURSEFLAG=/S
!ENDIF

SG_TOKENFILTER=cefilter
MAKECMD=$(MAKE) $(NMAKEDEBUG)

# Include standard makefile for all the link rules
_IN_CESYSGEN=1
!INCLUDE $(_MAKEENVROOT)\makefile.def

SG_INPUT_ROOT=$(_PUBLICROOT)\$(WINCEPROJ)
SG_INPUT_RESROOT=$(SG_INPUT_ROOT)\oak\res
SG_INPUT_LIB=$(SG_INPUT_ROOT)\oak\lib\$(_CPUINDPATH)
SG_INPUT_REPLACELIB=$(_PROJECTROOT)\oak\lib\$(_CPUINDPATH)
SG_INPUT_REPLACERESROOT=$(_PROJECTROOT)\oak\res
SG_OUTPUT_ROOT=$(_PROJECTROOT)\cesysgen
SG_OUTPUT_SDKLIB=$(SG_OUTPUT_ROOT)\sdk\lib\$(_CPUINDPATH)
SG_OUTPUT_OAKLIB=$(SG_OUTPUT_ROOT)\oak\lib\$(_CPUINDPATH)
SG_OUTPUT_OAKTGT=$(SG_OUTPUT_ROOT)\oak\target\$(_CPUINDPATH)

sysgen:preproc postproc

#
# The last phase of sysgen is to copy usa & localized RES files from SG_INPUT_LIB to SG_OUTPUT_OAKTGT
# SYSGEN.BAT hands us _LANGIDLIST as the list of languages for which localized RESs exist
#

postlocalize:: 0409 $(_LANGIDLIST)

0409 $(_LANGIDLIST)::
	-@mkdir $(SG_OUTPUT_OAKTGT)\$@ > nul $(SG_XCOPYREDIRECT)
	-@echo Copying localized RESs for $@ to $(SG_OUTPUT_OAKTGT)\$@
        -@xcopy /I $(SG_INPUT_LIB)\$(@:0409=.)\*.res $(SG_OUTPUT_OAKTGT)\$@ > nul

# !IF "$(WINCEREL)" == "1"
# postlocalize::
# 	-@echo WINCEREL set--Copying $(WINCEPROJ).loc to $(_FLATRELEASEDIR)
# 	-@xcopy /I $(SG_OUTPUT_OAKTGT)\$(WINCEPROJ).loc $(_FLATRELEASEDIR) > nul
# 
# 0409 $(_LANGIDLIST)::
# 	-@echo WINCEREL set--Copying resources from $(SG_OUTPUT_OAKTGT)\$@ to $(_FLATRELEASEDIR)\$@
# 	-@xcopy /I $(SG_OUTPUT_OAKTGT)\$@\*.res $(_FLATRELEASEDIR)\$@ > nul
# !ENDIF


#
# These are default rules to help link componentized modules. They force a two stage link where
# you first build a single library and then link the exe, with the stubs listed as one of the
# TARGETLIBS. This prevents picking up of entry points from the stub instead of the real component.
#

# Default link rules for libs, exes and dlls
$(TARGETNAME)_ALL.lib:
	@set TARGETTYPE=LIBRARY
	$(MAKECMD) /NOLOGO TARGETNAME=$(TARGETNAME)_ALL RELEASETYPE=OAK $(SG_OUTPUT_OAKLIB)\$@

$(TARGETNAME).exe:$(TARGETNAME)_ALL.lib
	@set TARGETTYPE=PROGRAM
	@set TARGETLIBS=$(SG_OUTPUT_OAKLIB)\$(TARGETNAME)_ALL.lib $(TARGETLIBS)
	$(MAKECMD) /NOLOGO $(SG_OUTPUT_OAKTGT)\$@

$(TARGETNAME).dll:$(TARGETNAME)_ALL.lib
	@set TARGETTYPE=DYNLINK
	@set SOURCELIBS=$(SG_OUTPUT_OAKLIB)\$(TARGETNAME)_ALL.lib
	@set DEFFILE=$(SG_OUTPUT_OAKLIB)\$(TARGETNAME).def
	$(SG_TOKENFILTER) $(SG_INPUT_LIB)\$(TARGETNAME).def $(SG_OUTPUT_OAKLIB)
	$(MAKECMD) /NOLOGO $(SG_OUTPUT_OAKTGT)\$@


